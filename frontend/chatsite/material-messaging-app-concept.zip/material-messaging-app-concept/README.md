# Material Messaging App Concept

A Pen created on CodePen.io. Original URL: [https://codepen.io/ThomasDaubenton/pen/QMqaBN](https://codepen.io/ThomasDaubenton/pen/QMqaBN).

